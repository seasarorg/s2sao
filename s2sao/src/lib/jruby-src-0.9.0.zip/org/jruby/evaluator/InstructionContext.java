package org.jruby.evaluator;

public interface InstructionContext {
    // TODO nothing here yet...
}
